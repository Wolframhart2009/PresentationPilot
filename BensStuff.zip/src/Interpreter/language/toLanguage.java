package interpreter.language;


public interface toLanguage {
	
	public String Translate(String s);
	public String buildDoc(String s);
	public String getHeader(); 
}
